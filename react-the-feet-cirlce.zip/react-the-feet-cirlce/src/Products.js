import React, { useState, useEffect } from "react";
import "./index.css";
import { Link } from "react-router-dom";

function Products() {
  const [data, setData] = useState([]);
  const [originaldata, setOrginalData] = useState([]);
  const [filteroptions, setFilterOptions] = useState([]);
  const [selectedOption, setSelectedOption] = useState(""); // State to store the selected option

  useEffect(() => {
    const getdata = async () => {
      const result = await fetch("https://dummyjson.com/products");
      const response = await result.json();
      setData(response.products);
      setOrginalData(response.products);
    };
    getdata();
  }, []);

  useEffect(() => {
    var options;
    if (data.length > 0) {
      options = [
        ...new Set(
          originaldata.map((pro) => {
            return pro.category;
          })
        )
      ];
      console.log("options", options);
      setFilterOptions(options);
    }
  }, [originaldata]);
  console.log("data", data);
  console.log("filteroptions", filteroptions);

  const getSelectedOption = (event) => {
    setSelectedOption(event.target.value);
    console.log("selected", event.target.value);
    if (event.target.value === "ALL") {
      setData(originaldata);
    } else {
      console.log("in else", originaldata);
      const filterdata = originaldata.filter(
        (d) => d.category.toLowerCase() === event.target.value.toLowerCase()
      );
      console.log("d", filterdata);
      setData(filterdata);
    }
  };
  return (
    <>
      Filter :{" "}
      <select onChange={getSelectedOption}>
        <option value="ALL">ALL</option>
        {filteroptions.map((opt) => {
          return <option key={opt.key}>{opt}</option>;
        })}
      </select>
      <div className="product-container">
        {data.map((pro) => (
          <Link to={`/product/${pro.id}`}>
            <div key={pro.id} className="product-item">
              <div className="product-image">
                <img src={pro.thumbnail} alt={pro.title} />
              </div>
              <div className="product-description">
                <p className="pro-title">{pro.title}</p>
                <p className="pro-price">${pro.price}</p>
              </div>
              <div className="pro-des">
                <p>{pro.description}</p>
              </div>
            </div>
          </Link>
        ))}
      </div>
    </>
  );
}

export default Products;
