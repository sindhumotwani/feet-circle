// App.js or your top-level component
import React from "react";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom"; // Import Routes
import Products from "./Products";
import ProductDetail from "./ProductDetail";

function App() {
  return (
    <Router>
      <Routes>
        {" "}
        {/* Use the Routes component as the container for your routes */}
        <Route path="/" element={<Products />} />
        <Route path="/product/:id" element={<ProductDetail />} />
      </Routes>
    </Router>
  );
}

export default App;
