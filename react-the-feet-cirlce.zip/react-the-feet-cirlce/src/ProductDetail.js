import React, { useState, useEffect } from "react";
import { useParams } from "react-router-dom";
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";

function ProductDetail() {
  const sliderSettings = {
    infinite: true,
    slidesToShow: 1,
    slidesToScroll: 1,
    vertical: true,
    speed: 500,
    autoplay: true,
    autoplaySpeed: 100,
    arrows: false // Hide the arrows
  };

  const [data, setData] = useState([]);
  let { id } = useParams();
  useEffect(() => {
    const getdata = async () => {
      const result = await fetch(`https://dummyjson.com/products/${id}`);
      const response = await result.json();
      setData(response);
      console.log("response", response);
    };
    getdata();
  }, []);

  return (
    <div className="single-pro-container">
      <div className="single-pro-img">
        <img src={data.thumbnail} alt="" />
      </div>
      <div className="slider-container">
        <Slider {...sliderSettings}>
          {data?.images?.map((item) => {
            return (
              <div>
                <img src={item} />
              </div>
            );
          })}
        </Slider>
      </div>
      <div className="single-pro-details">
        <h2>{data.title}</h2>
        <div>{data.description}</div>
        <div>
          <p>$ {data.price}</p>
        </div>
      </div>
    </div>
  );
}
export default ProductDetail;
